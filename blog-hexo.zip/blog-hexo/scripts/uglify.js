// var UglifyJS = require("uglify-js")

// hexo.extend.filter.register('after_render:js', function (str, data) {
//   var result = UglifyJS.minify(str)
//   return result.code
// });

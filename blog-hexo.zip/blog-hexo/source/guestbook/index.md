---
title: 留言板
date: 2016-11-10 20:35:52
comments: true
---

<blockquote class="blockquote-center">I eat alone. I sleep alone. I cry alone. So….cool.</blockquote>

<center> 你想说些什么呢？就在这里回复吧~ 欢迎灌水，来者不拒！<br>如果你觉得我的博客对你有价值，并且有帮助到你，欢迎向我捐赠，就当是请我喝杯饮料~ <br><b>另外,你确定就看看不留个爪爪么!</b></center>

<div style="margin: 20px auto; width: 100%; text-align: center">
    <a href="/qcode/alipay_qcode.png" class="group-picture">
      <img src="/qcode/alipay_qcode.png" alt="支付宝打赏" style="width: 200px; max-width: 100%;">
    </a>
    <div>支付宝打赏</div>
</div>

***

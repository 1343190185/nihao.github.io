---
title: 关于我
date: 2016-11-09 09:58:04
comments: true
---

<blockquote class="blockquote-center">愿多年以后，我可以酌一杯清酒，烂醉如泥，梦中回到我们的曾经。</blockquote>

<center>首先梦魇小栈欢迎您的到来!</center>

> <p style="text-indent: .5em; margin-bottom: 10px;">关于我</p>

90后,技术宅?恩或许是,现居于北京,然后喜爱折腾,好奇新事物
欢迎各位小伙伴与我互换友链，详情请戳 上面的 <a href="/links"><b>链接</b></a> 页面 。
关于这个站呢,就是记录下平时记不太住的还有一些自己感兴趣喜欢的一些东西
顺便也分享给大家吧!
就酱紫,联系方式在下面

***

<center> <h2>联系方式</h2> </center>

- Email：<a href="https://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=mail@ihoey.com">mail@ihoey.com</a>
- Q  Q：<a href="http://wpa.qq.com/msgrd?v=3&uin=1058221214&site=qq&menu=yes">1058221214</a>
- 微博：<a href="http://weibo.com/hy951121">ihoeys</a>
- 欢迎加入QQ群：<a href="https://shang.qq.com/wpa/qunwpa?idkey=9049819d22fc4a5c4906cc246fec5236c193ff1b2ad365530ead8c3590cfac06">点我呀！413700874</a>

***

<blockquote class="blockquote-center">Let life be beautiful like summer flowers and death like autumn leaves.</blockquote>

***

[2016-10-25] 站点从SinaAppEngine(SAE)迁移到Coding/GitHub, 国内用户默认解析至Coding, 海外则解析至GitHub, 互为备份, 改善了访问速度与稳定性

***

<center> <h2>打赏记录</h2> </center><br>

| 打赏人         | 打赏留言                        | 打赏时间    |
| :--:          | :--:                           | :--:       |
| 159**0212     | 小站不错，支持一下啦~             | 2015-11-02 |
| 138**4533     | 我来啦，占前排~                  | 2015-11-02 |
| 188**5838     | 网站不错哦!                      | 2015-12-14 |
| 175**1534     | 新年快乐!！                      | 2016-2-11  |
| 131**7309     | 很漂亮的网站,我的零钱都给你啦!      | 2016-3-15  |
| 1121**@qq.com | 谢谢帮助,祝你888!                | 2016-6-20  |
| lw**@163.com  | 那我就给你来个666吧!              | 2016-6-21  |

<br>

啦啦啦，感谢你们啦，我会做的更好的呢
2016-6-25:感谢你们的赞助了.虽然人不多,但我还是很感动的.
2017-6-5:今天早上发现多说突然就废了,然后就紧急的换成了网易云跟帖,评论系统样式不是很好看,主要的是以前多说的数据导入过来有好多都不显示,唉……伤心！

***

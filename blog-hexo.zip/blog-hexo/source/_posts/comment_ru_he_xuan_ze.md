---
title: 继多说、网易关停之后该何去何从(网易云跟帖宣布2017年8月1日停止服务)
date: 2017-7-6 18:51:21
tags:
  - comment
categories: Linux
---

![comment_ihoey](https://cdn.dode.top/IHOEY_20170706_184907.png?imageView2/0/format/png/q/75|imageslim)
继多说（多说关闭想必大家都已经知道了）关闭之后，很多人包括我，都转移到了网易云跟帖，现在网易云跟帖也正式发出公告宣布于 2017 年 8 月 1 日停止服务。

<!-- more -->

在多说关闭之后，使用网易云跟帖的站点非常多，昨日宣布停止服务，小编也感到很意外。官方在 QQ 群内通知并没有说明具体原因，或许还是评论服务的老话题——盈利！

并且 QQ 群管理称涉及网易自身评论，开源几乎不大！

这是提前在官方群得到的通知！
![comment_ihoey](https://cdn.dode.top/IHOEY_20170706_171445.png?imageView2/0/format/png/q/75|imageslim)

多说刚挂了两个月，跟帖也跟着去了，刚做的提醒小功能都还没怎么用，好伤心，不知道小伙伴下一步都选择什么呢？有好用的推荐一下啊！
![comment_ihoey](https://cdn.dode.top/IHOEY_20170706_171444.png?imageView2/0/format/png/q/75|imageslim)
